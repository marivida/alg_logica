//Sub-Rotina (Funcao) com passagem de parametros e com retorno


#include <stdio.h>
int soma(int a,int b )
{
		return a + b;

}
int main()
{
	int n1,n2;
  printf("\nDigite um n�mero n1: ");
  scanf("%d%*c",&n1);
  printf("\nDigite um n�mero n1: ");
  scanf("%d%*c",&n2);
  printf("\nA soma � : %d   ",soma(n1,n2));
  getchar();
  return 0;
}
