//Sub-Rotina (Funcao) sem passagem de parametros e com retorno


#include <stdio.h>
int soma()
{
	int a,b;
	printf("\nDigite um n�mero a: ");
    scanf("%d%*c",&a);
    printf("\nDigite um n�mero b: ");
    scanf("%d%*c",&b);
	return a + b;
}
int main()
{

  printf("\n HOJE � DIA DE LOGICA: ");
  printf("\n ISSO � MUITO BOM, POIS LOGICA � LEGAL: ");
  printf("\nA soma � : %d   ",soma());
  getchar();
  return 0;
}
