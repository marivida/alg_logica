//Sub-Rotina (Funcao) com passagem de parametros e sem retorno


#include <stdio.h>
void soma(int a,int b )
{
	int res;
	res = a + b;
    printf("\nA soma � : %d   ",res);
}
int main()
{
	int n1,n2;
  printf("\nDigite um n�mero n1: ");
  scanf("%d%*c",&n1);
  printf("\nDigite um n�mero n1: ");
  scanf("%d%*c",&n2);
  soma(n1,n2);
  getchar();
  return 0;
}
