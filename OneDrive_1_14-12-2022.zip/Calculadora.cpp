#include <stdio.h>

int soma(int a, int b);
int sub(int a, int b);
int mult(int a, int b);

int main(){
	int a, b, resSoma, resSub, resMult;
	printf("Digite dois numeros inteiros\n");
    scanf ("%d",&a);
    scanf ("%d",&b);
    resSoma = soma(a, b);
    resSub = sub(a,b);
	resMult = mult(a, b);
    printf ("\n A soma dos dois numeros eh: %d", resSoma);
    printf ("\n A subtracao dos dois numeros eh: %d", resSub);
    printf ("\n A multiplicacao dos dois numeros eh: %d", resMult);
    getchar();
	return 0;
}

int soma (int n1, int n2){
	int soma;
	soma = n1+n2;
	return soma;
}

int sub (int x, int y){
	int sub;
	sub = x-y;
	return sub;
}

int mult (int w, int z){
	int mult;
	mult = w*z;
	return mult;
} 
