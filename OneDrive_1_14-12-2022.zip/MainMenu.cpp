#include <stdio.h>
#include <stdlib.h>
#include "idade.c" // respons�vel por chamar o arquivo fonte idade.c
#include "imc.c"
#include "estudo.c"

int main(){ 
	int opc;
	do 
	{
		system("cls");
		printf("\n Escolha uma das funcoes abaixo:");
		printf("\n 1- Calculo da sua idade");
		printf("\n 2- Calculo do seu IMC");
		printf("\n 3- Calculo do seu tempo medio de estudo semanal");
		printf("\n 4- Saida do programa");
		printf("\n");
		scanf("%d%*c",&opc);
		switch(opc)
		{
			case 1:
			{
				idade(); //chamando fun��o para ser executada
				break;
			}
			case 2: 
			{
				imc(); 
				break;
			}
			case 3:
			{
				estudo(); 
				break;
			}
			case 4:
			{
				printf("\n Saida do programa");
				getchar();
				break;
			}
			default:
			{
				printf("\n Opcao invalida...");
				getchar();
				break;
			}
		}
	}while(opc!=4);
	return 0;
}

