#include <stdio.h>

void imc(){
float peso, altura, imc;
	printf("\n Digite seu peso:");
	scanf("%f%*c",&peso);
	printf("\n Digite sua altura");
	scanf("%f%*c",&altura);
	imc=peso/(altura*altura);
	printf("\n Seu IMC eh de: %0.2f",imc);
	getchar();
}

