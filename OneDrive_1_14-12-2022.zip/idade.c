#include <stdio.h>

void idade(){
	int dn, dh, idade;
	printf("Digite o ano atual: ");
	scanf("%d%*c",&dh);
	printf("Digite o ano do seu nascimento: ");
	scanf("%d%*c",&dn);
	idade = dh-dn;
	printf("\n Sua idade atual em anos: %d anos.",idade);
	getchar();
}

