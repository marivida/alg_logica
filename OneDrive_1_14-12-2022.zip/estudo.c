#include <stdio.h>

void estudo(){
float s, t, q, qq, sx, ss, d, final;
	printf("\n Digite a quantidade de horas disponiveis para estudo na:");
	printf(" 2a feira: ");
	scanf("%f%*c",&s);
	printf("\n 3a feira: ");
	scanf("%f%*c",&t);
	printf("\n 4a feira: ");
	scanf("%f%*c",&q);
	printf("\n 5a feira: ");
	scanf("%f%*c",&qq);
	printf("\n 6a feira: ");
	scanf("%f%*c",&sx);
	printf("\n no sabado: ");
	scanf("%f%*c",&sx);
	printf("\n no domingo: ");
	scanf("%f%*c",&d);
	final=(s+t+q+qq+sx+ss+d)/7;
	printf("\n Seu tempo medio de estudo semanal eh de: %0.2f horas semanais",final);
	getchar();
}
