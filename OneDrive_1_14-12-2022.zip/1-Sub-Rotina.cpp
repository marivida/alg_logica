//Sub-Rotina (Funcao) sem passagem de parametros e sem retorno



#include <stdio.h>
void soma()
{
	int a,b,res;
	printf("\nDigite um n�mero a: ");
    scanf("%d%*c",&a);
    printf("\nDigite um n�mero b: ");
    scanf("%d%*c",&b);
	res = a + b;
    printf("\nA soma � : %d   ",res);
 }
int main()
{
  printf("\n HOJE � DIA DE LOGICA: ");
  printf("\n ISSO � MUITO BOM, POIS LOGICA � LEGAL: ");
  soma();
  getchar();
  return 0;
}
